package project.pkg1floodit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Project1Floodit {

    public static final String YELLOW = "\u001b[33;1m";
    public static final String CYAN = "\u001b[36;1m";
    public static final String MAGENTA = "\u001b[35;1m";
    public static final String BLUE = "\u001b[34;1m";
    public static final String GREEN = "\u001b[32;1m";
    public static final String RED = "\u001b[31;1m";

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Choose number of Colores [3 - 6]: ");
        int numOfColor = input.nextInt();

        while (numOfColor < 3 || numOfColor > 6) {
            System.out.print("\nWrong number of Colores! Choose again: ");
            numOfColor = input.nextInt();
        }

        System.out.print("\nChoose size of the boared nxn [n: 4 - 12]: ");
        int n = input.nextInt();

        while (n < 4 || n > 12) {
            System.out.print("\nWrong size! Choose again: ");
            n = input.nextInt();
        }

        int[][] grid = new int[n][n];
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                grid[i][j] = (int) (Math.random() * numOfColor);
            }
        }

        System.out.print("\nWelcome! menu: "
                + "\n\t1. Solve by Greedy Search"
                + "\n\t2. Solve by A* Search"
                + "\n\t3. Solve by both Greedy and A* Search"
                + "\n\t4. Exit ");

        System.out.print("\nChoose your option: ");
        int h = input.nextInt();
        int[][] copyGrid = new int[grid.length][grid.length];
        int[][] copyGrid2 = new int[grid.length][grid.length];

        do {
            switch (h) {
                case 1:
                    break;
                case 2:
                    for (int k = 0; k < grid.length; k++) {

                        for (int j = 0; j < grid.length; j++) {
                            copyGrid[k][j] = grid[k][j];
                        }
                    }
                    break;
                case 3:
                    for (int k = 0; k < grid.length; k++) {
                        for (int j = 0; j < grid.length; j++) {
                            copyGrid[k][j] = grid[k][j];
                            copyGrid2[k][j] = grid[k][j];
                        }
                    }
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.print("\nWrong size! Choose again: ");
                    h = input.nextInt();
            }
        } while (h < 1 || h > 3);

        print(grid);
        System.out.println("\n\n");

        int newColor;
        int allowedMoves = (int) (calculateBaselineMovesLeft((grid.length * grid.length), 1, grid, numOfColor));
        int moves = allowedMoves;
        System.out.println("no. moves allowed: " + allowedMoves);

        boolean h3g = false;
        boolean h3a = false;
        boolean h3a2 = false;

        if (h == 1) {
            while (!checkWin(grid) && moves != 0) {

                newColor = greedy(grid);

                floodIt(0, 0, newColor, grid[0][0], grid);
                moves--;
                print(grid);

                System.out.println("\n");
            }
            System.out.println("no. moves used " + (allowedMoves - moves));

        } else if (h == 2) {

            int aMove = moves;
            int a2Move = moves;

            while (moves != 0) {

                if (!checkWin(grid)) {
                    newColor = Astarh1(grid);
                    aMove--;
                    floodIt(0, 0, newColor, grid[0][0], grid);
                    if (checkWin(grid)) {
                        h3a = true;
                    }
                }
                if (!checkWin(copyGrid)) {
                    newColor = Astarh2(copyGrid);
                    a2Move--;
                    floodIt(0, 0, newColor, copyGrid[0][0], copyGrid);
                    if (checkWin(copyGrid)) {
                        h3a2 = true;
                    }
                }
                moves--;
                print2(grid, copyGrid);
                if (h3a && h3a2) {
                    break;
                }
                System.out.println("\n");
            }

            System.out.print("\tno. moves used by A* h1: " + (allowedMoves - aMove));
            System.out.print("\tno. moves used in A* h2: " + (allowedMoves - a2Move) + "\n");
        } else {
            int gMove = moves;
            int aMove = moves;
            int a2Move = moves;

            while (moves != 0) {

                if (!checkWin(grid)) {
                    newColor = greedy(grid);
                    gMove--;
                    floodIt(0, 0, newColor, grid[0][0], grid);
                    if (checkWin(grid)) {
                        h3g = true;
                    }
                }

                if (!checkWin(copyGrid)) {
                    newColor = Astarh1(copyGrid);
                    aMove--;
                    floodIt(0, 0, newColor, copyGrid[0][0], copyGrid);
                    if (checkWin(copyGrid)) {
                        h3a = true;
                    }
                }
                if (!checkWin(copyGrid2)) {
                    newColor = Astarh2(copyGrid2);
                    a2Move--;
                    floodIt(0, 0, newColor, copyGrid2[0][0], copyGrid2);
                    if (checkWin(copyGrid2)) {
                        h3a2 = true;
                    }
                }
                moves--;
                print3(grid, copyGrid, copyGrid2);
                if (h3g && h3a && h3a2) {
                    break;
                }
                System.out.println("\n");
            }

            System.out.print("\nno. moves used by greedy h1:" + (allowedMoves - gMove));
            System.out.print("\t, no. moves used by A* h1:" + (allowedMoves - aMove));
            System.out.print("\t, no. moves used in A* h2:" + (allowedMoves - a2Move) + "\n");
        }

    }

    public static double calculateBaselineMovesLeft(int iterations, int tops, int[][] grid, int numOfColor) {
        if (tops > iterations) {
            throw new IllegalArgumentException("requesting the average of more result than that is generated");
        }
        int[] testResults = new int[iterations]; //the choice of 30 iterations is completely arbitrary. Feel free to change it. 

        for (int i = 0; i < testResults.length; i++) {
            int[][] testGrid = new int[grid.length][grid.length];

            for (int k = 0; k < grid.length; k++) {
                for (int j = 0; j < grid.length; j++) {
                    testGrid[k][j] = grid[k][j];
                }
            }

            int movesUsed = 0;
            while (!checkWin(testGrid)) {
                int newColor;
                do {
                    newColor = (int) (Math.random() * numOfColor);
                } while (newColor == testGrid[0][0]);

                floodIt(0, 0, newColor, testGrid[0][0], testGrid);
                movesUsed++;
            }
            testResults[i] = movesUsed;
        }

        Arrays.sort(testResults);

        int sum = 0;
        for (int i = 0; i < tops; i++) {
            sum += testResults[i];
        }
        return (double) sum / tops;
    }

    public static void floodIt(int x, int y, int newColor, int oldColor, int[][] grid) {
        if (newColor == oldColor) {
            throw new IllegalArgumentException("newColor and oldColor should not be the same!");
        }
        if (x < 0 || y < 0 || x >= grid.length || y >= grid.length) {
            return;
        }
        if (grid[x][y] != oldColor) {
            return;
        }
        grid[x][y] = newColor;
        floodIt(x, y + 1, newColor, oldColor, grid);
        floodIt(x, y - 1, newColor, oldColor, grid);
        floodIt(x + 1, y, newColor, oldColor, grid);
        floodIt(x - 1, y, newColor, oldColor, grid);
        return;
    }

    public static boolean checkWin(int[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                if (grid[i][j] != grid[0][0]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static int greedy(int[][] grid) {

        ArrayList<Integer> flood = new ArrayList<>();
        ArrayList<Integer> potential = new ArrayList<>();

        flood.add(0);
        flood.add(0);
        potential.add(-1);
        potential.add(-1);

        for (int e = 0; e < flood.size(); e += 2) {
            int i = flood.get(e);
            int j = flood.get(e + 1);
            checkFlood(flood, potential, i, j, grid);
        }

        int[] h = heauristic1(potential, grid);

        int max = h[0];
        int color = 0;

        System.out.print("\nGreedy ");
        for (int i = 1; i < 6; i++) {
            if (max < h[i]) {
                max = h[i];
                color = i;

            }
        }

        System.out.println("Choose " + printColor(color) + " h(n) = " + (h[color]));

        potential.clear();
        flood.clear();
        return color;
    }

    public static int Astarh1(int[][] grid) {

        ArrayList<Integer> flood = new ArrayList<>();
        ArrayList<Integer> potential = new ArrayList<>();

        flood.add(0);
        flood.add(0);
        potential.add(-1);
        potential.add(-1);

        for (int e = 0; e < flood.size(); e += 2) {
            int i = flood.get(e);
            int j = flood.get(e + 1);
            checkFlood(flood, potential, i, j, grid);
        }

        int[] h = heauristic1(potential, grid);

        for (int i = 0; i < h.length; i++) {
            h[i] += 1;
        }

        int max = h[0];
        int color = 0;
        //System.out.print("\t\t\t\tA*h1 ");
        for (int i = 1; i < 6; i++) {
            if (max < h[i]) {
                max = h[i];
                color = i;

            }
        }

        System.out.println("Choose " + printColor(color) + " f(n) = " + (h[color]));
        potential.clear();
        flood.clear();
        return color;
    }

    public static int Astarh2(int[][] grid) {

        ArrayList<Integer> flood = new ArrayList<>();
        ArrayList<Integer> potential = new ArrayList<>();

        flood.add(0);
        flood.add(0);
        potential.add(-1);
        potential.add(-1);

        for (int e = 0; e < flood.size(); e += 2) {
            int i = flood.get(e);
            int j = flood.get(e + 1);
            checkFlood(flood, potential, i, j, grid);
        }

        for (int k = 2; k < potential.size(); k += 2) {
            int i = potential.get(k);
            int j = potential.get(k + 1);
            checkPotential(flood, potential, k, i, j, grid);
        }

        int color = heauristic2(potential, grid);

        potential.clear();
        flood.clear();
        return color;
    }

    public static boolean checkInArray(ArrayList<Integer> F, int i, int j) {
        for (int k = 0; k < F.size(); k += 2) {
            if (F.get(k) == i && F.get(k + 1) == j) {
                return false;
            }
        }
        return true;
    }

    public static void checkFlood(ArrayList<Integer> flood, ArrayList<Integer> potential, int i, int j, int[][] grid) {

        if (j + 1 < grid.length && grid[i][j + 1] == grid[0][0]) {
            if (checkInArray(flood, i, j + 1)) {
                flood.add(i);
                flood.add(j + 1);
            }
        } else {
            if (j + 1 < grid.length && checkInArray(potential, i, j + 1)) {
                potential.add(i);
                potential.add(j + 1);
            }
        }

        if (i + 1 < grid.length && grid[i + 1][j] == grid[0][0]) {
            if (checkInArray(flood, i + 1, j)) {
                flood.add(i + 1);
                flood.add(j);
            }
        } else {
            if (i + 1 < grid.length && checkInArray(potential, i + 1, j)) {
                potential.add(i + 1);
                potential.add(j);
            }
        }

        if (j > 0 && grid[i][j - 1] == grid[0][0]) {
            if (checkInArray(flood, i, j - 1)) {
                flood.add(i);
                flood.add(j - 1);
            }
        } else {
            if (j > 0 && checkInArray(potential, i, j - 1)) {
                potential.add(i);
                potential.add(j - 1);
            }
        }

        if (i > 0 && grid[i - 1][j] == grid[0][0]) {
            if (checkInArray(flood, i - 1, j)) {
                flood.add(i - 1);
                flood.add(j);
            }
        } else {
            if (i > 0 && checkInArray(potential, i - 1, j)) {
                potential.add(i - 1);
                potential.add(j);
            }
        }
    }

    public static void checkPotential(ArrayList<Integer> flood, ArrayList<Integer> potential, int k, int i, int j, int[][] grid) {

        if (j + 1 < grid.length && grid[i][j + 1] == grid[potential.get(k)][potential.get(k + 1)]) {
            if (checkInArray(potential, i, j + 1)) {
                potential.add(i);
                potential.add(j + 1);
            }
        }

        if (i + 1 < grid.length && grid[i + 1][j] == grid[potential.get(k)][potential.get(k + 1)]) {
            if (checkInArray(potential, i + 1, j)) {
                potential.add(i + 1);
                potential.add(j);
            }
        }

        if (j > 0 && grid[i][j - 1] == grid[potential.get(k)][potential.get(k + 1)]) {
            if (checkInArray(potential, i, j - 1)) {
                potential.add(i);
                potential.add(j - 1);
            }
        }

        if (i > 0 && grid[i - 1][j] == grid[potential.get(k)][potential.get(k + 1)]) {
            if (checkInArray(potential, i - 1, j)) {
                potential.add(i - 1);
                potential.add(j);
            }
        }
    }

    public static int[] heauristic1(ArrayList<Integer> potential, int[][] grid) {
        int[] count = new int[6];
        for (int k = 2; k < potential.size(); k += 2) {
            switch (grid[potential.get(k)][potential.get(k + 1)]) {
                case 0:
                    count[0]++;
                    break;
                case 1:
                    count[1]++;
                    break;
                case 2:
                    count[2]++;
                    break;
                case 3:
                    count[3]++;
                    break;
                case 4:
                    count[4]++;
                    break;
                case 5:
                    count[5]++;
                    break;
            }
        }

        return count;
    }

    public static int heauristic2(ArrayList<Integer> potential, int[][] grid) {

        int[] count = new int[6];
        int[] max = new int[6];
        int[] jMax = new int[6];

        for (int k = 2; k < potential.size(); k += 2) {

            switch (grid[potential.get(k)][potential.get(k + 1)]) {
                case 0:
                    count[0]++;
                    if (potential.get(k) + potential.get(k + 1) > max[0]) {
                        max[0] = potential.get(k) + potential.get(k + 1);
                        jMax[0] = potential.get(k + 1);
                    }
                    break;
                case 1:
                    count[1]++;
                    if (potential.get(k) + potential.get(k + 1) > max[1]) {
                        max[1] = potential.get(k) + potential.get(k + 1);
                        jMax[1] = potential.get(k + 1);
                    }
                    break;
                case 2:
                    count[2]++;
                    if (potential.get(k) + potential.get(k + 1) > max[2]) {
                        max[2] = potential.get(k) + potential.get(k + 1);
                        jMax[2] = potential.get(k + 1);
                    }
                    break;
                case 3:
                    count[3]++;
                    if (potential.get(k) + potential.get(k + 1) > max[3]) {
                        max[3] = potential.get(k) + potential.get(k + 1);
                        jMax[3] = potential.get(k + 1);
                    }
                    break;
                case 4:
                    count[4]++;
                    if (potential.get(k) + potential.get(k + 1) > max[4]) {
                        max[4] = potential.get(k) + potential.get(k + 1);
                        jMax[4] = potential.get(k + 1);
                    }
                    break;
                case 5:
                    count[5]++;
                    if (potential.get(k) + potential.get(k + 1) > max[5]) {
                        max[5] = potential.get(k) + potential.get(k + 1);
                        jMax[5] = potential.get(k + 1);
                    }
                    break;
            }
        }
        for (int i = 0; i < count.length; i++) {

            count[i] = count[i] + 1;

        }

        int Max = count[0] + max[0];
        int color = 0;
        //System.out.print("\t\t\t\tA*h2 ");
        for (int i = 1; i < 6; i++) {
            if (Max < (count[i] + max[i])) {
                Max = count[i] + max[i];
                color = i;
                jMax[0] = jMax[i];
            } else if (Max == (count[i] + max[i])) {
                if (jMax[0] < jMax[i]) {
                    Max = count[i] + max[i];
                    color = i;
                    jMax[0] = jMax[i];
                }
            }

        }

        System.out.println("Choose " + printColor(color) + " f(n) = " + Max + "\n");

        return color;

    }

    public static void print(int[][] grid) {
        System.out.print("\n");

        for (int i = 0; i < grid.length; i++) {

            System.out.print("\t\t\t\t");

            for (int j = 0; j < grid[0].length; j++) {

                switch (grid[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }

            }

            System.out.print("\n");

        }
    }

    public static void print2(int[][] grid, int[][] copyGrid) {

        if (checkWin(grid) || checkWin(copyGrid)) {
            System.out.println("\n");
        }

        for (int i = 0; i < grid.length; i++) {

            System.out.print("\t\t\t\t");

            for (int j = 0; j < grid[0].length; j++) {

                switch (grid[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }
            }
            System.out.print("\t\t\t\t");
            for (int j = 0; j < copyGrid[0].length; j++) {

                switch (copyGrid[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }
            }

            System.out.print("\n");

        }
    }

    public static void print3(int[][] grid, int[][] copyGrid, int[][] copyGrid2) {

        if (checkWin(grid) || checkWin(copyGrid) || checkWin(copyGrid2)) {
            System.out.println("\n");
        }

        for (int i = 0; i < grid.length; i++) {

            System.out.print("\t");

            for (int j = 0; j < grid[0].length; j++) {

                switch (grid[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }
            }
            System.out.print("\t\t");
            for (int j = 0; j < copyGrid[0].length; j++) {

                switch (copyGrid[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }
            }

            System.out.print("\t\t");
            for (int j = 0; j < copyGrid2[0].length; j++) {

                switch (copyGrid2[i][j]) {
                    case 0:
                        System.out.print(MAGENTA + "■  " + MAGENTA);
                        break;
                    case 1:
                        System.out.print(CYAN + "■  " + CYAN);
                        break;
                    case 2:
                        System.out.print(YELLOW + "■  " + YELLOW);
                        break;
                    case 3:
                        System.out.print(BLUE + "■  " + BLUE);
                        break;
                    case 4:
                        System.out.print(RED + "■  " + RED);
                        break;
                    case 5:
                        System.out.print(GREEN + "■  " + GREEN);
                        break;
                    default:
                        break;
                }
            }

            System.out.print("\n");

        }
    }

    public static String printColor(int color) {

        switch (color) {
            case 0:
                return ("MAGENTA");

            case 1:
                return ("CYAN");

            case 2:
                return ("YELLOW");

            case 3:
                return ("BLUE");

            case 4:
                return ("RED");

            case 5:
                return ("GREEN");
            default:
                return "";
        }

    }

}
